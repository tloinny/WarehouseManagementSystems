1.安装MySql-8.0，安装workbench，运行目录中的warehouse_db.sql脚本，至此将数据库迁移到本机，完成数据库的准备
2.到\bin\release中找到WarehouseManagementSystem.exe，双击运行即可。

测试账号：
owner账号：sam
owner密码：1100111000

admin账号：tloinny
admin密码：1100111000

测试SKU映射表：

'1912140001', 'brushless dc motor
'1912140002', 'brushed dc motor'
'1912140003', '42 stepper motor'
'1912140004', 'Beagle Bone Green'
'1912140005', 'raspberry pi 4b+'
'1912140006', 'arduino uno'
'1912140007', 'arduino mega2560'
