#include "administrator.h"

administrator::administrator(int id, int w_id, QString name)
{
    adminID = id;
    adminWarehouseID = w_id;
    adminName = name;
}
