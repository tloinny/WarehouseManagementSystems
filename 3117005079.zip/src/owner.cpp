#include "owner.h"

Owner::Owner(int id, QString name)
{
    ownerID = id;
    ownerName = name;
}
